#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from coordinate_follower.action import FollowTarget
import os
import time

class FollowerClient(Node):
    def __init__(self):
        super().__init__('follower_client')
        self._client = ActionClient(self, FollowTarget, 'follow_target')

    def send_goals_from_file(self, file_path):
        self._client.wait_for_server()
        self.get_logger().info("Action server is ready.")

        with open(file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    x_str, y_str = line.split(',')
                    x, y = float(x_str.strip()), float(y_str.strip())
                except ValueError:
                    self.get_logger().error(f"Invalid line format: {line}")
                    continue

                goal_msg = FollowTarget.Goal()
                goal_msg.x = x
                goal_msg.y = y
                self.get_logger().info(f"Sending goal: ({x}, {y})")

                future = self._client.send_goal_async(goal_msg)
                rclpy.spin_until_future_complete(self, future)
                goal_handle = future.result()

                if not goal_handle.accepted:
                    self.get_logger().warn(f"Goal ({x}, {y}) was rejected")
                    continue

                result_future = goal_handle.get_result_async()
                rclpy.spin_until_future_complete(self, result_future)
                result = result_future.result().result

                if result.success:
                    self.get_logger().info(f"Goal result: success = True, message = '{result.message}'")
                else:
                    self.get_logger().warn(f"Goal result: success = False, message = '{result.message}'")

                time.sleep(1)  # wait a bit before sending next goal

def main(args=None):
    rclpy.init(args=args)
    client = FollowerClient()

    # Find coordinates.txt relative to script location
    script_dir = os.path.dirname(os.path.realpath(__file__))
    coords_file = os.path.join(script_dir, 'coordinates.txt')

    if os.path.exists(coords_file):
        client.send_goals_from_file(coords_file)
    else:
        client.get_logger().error(f"File not found: {coords_file}")

    client.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
