#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from coordinate_follower.action import FollowTarget
from rclpy.action import ActionClient
import time

class FollowerClient(Node):

    def __init__(self):
        super().__init__('follower_client')
        self._client = ActionClient(self, FollowTarget, 'follow_target')

    def send_goal(self, x, y):
        self._client.wait_for_server()
        goal_msg = FollowTarget.Goal()
        goal_msg.x = x
        goal_msg.y = y

        self.get_logger().info(f'Sending goal: x={x}, y={y}')
        future = self._client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, future)
        goal_handle = future.result()

        if not goal_handle.accepted:
            self.get_logger().error('Goal rejected!')
            return

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        result = result_future.result().result

        self.get_logger().info(f'Result: success={result.success}, message="{result.message}"')

def main(args=None):
    rclpy.init(args=args)
    node = FollowerClient()

    # Load coordinates from file
    try:
        with open('scripts/coordinates.txt', 'r') as file:
            for line in file:
                x_str, y_str = line.strip().split(',')
                node.send_goal(float(x_str), float(y_str))
                time.sleep(1.0)
    except FileNotFoundError:
        node.get_logger().error("coordinates.txt not found!")

    node.destroy_node()
    rclpy.shutdown()
