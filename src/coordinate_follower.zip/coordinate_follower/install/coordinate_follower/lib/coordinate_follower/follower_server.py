#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from coordinate_follower.action import FollowTarget
from rclpy.action import ActionServer
from rclpy.executors import MultiThreadedExecutor
from rclpy.callback_groups import ReentrantCallbackGroup

from geometry_msgs.msg import Twist
import time

class FollowerServer(Node):

    def __init__(self):
        super().__init__('follower_server')
        self._action_server = ActionServer(
            self,
            FollowTarget,
            'follow_target',
            self.execute_callback,
            callback_group=ReentrantCallbackGroup()
        )
        self.cmd_vel_publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.get_logger().info("Follower Server is up and running.")

    async def execute_callback(self, goal_handle):
        self.get_logger().info(f"Received goal: x={goal_handle.request.x}, y={goal_handle.request.y}")

        twist = Twist()
        twist.linear.x = float(goal_handle.request.x)
        twist.angular.z = float(goal_handle.request.y)
        self.cmd_vel_publisher.publish(twist)

        self.get_logger().info("Published cmd_vel command.")

        time.sleep(2.0)

        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.cmd_vel_publisher.publish(twist)

        result = FollowTarget.Result()
        result.success = True
        result.message = "Target followed successfully."
        return result

def main(args=None):
    rclpy.init(args=args)
    node = FollowerServer()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    rclpy.shutdown()
