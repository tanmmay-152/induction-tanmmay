// generated from rosidl_generator_c/resource/idl.h.em
// with input from coordinate_follower:action/FollowTarget.idl
// generated code does not contain a copyright notice

#ifndef COORDINATE_FOLLOWER__ACTION__FOLLOW_TARGET_H_
#define COORDINATE_FOLLOWER__ACTION__FOLLOW_TARGET_H_

#include "coordinate_follower/action/detail/follow_target__struct.h"
#include "coordinate_follower/action/detail/follow_target__functions.h"
#include "coordinate_follower/action/detail/follow_target__type_support.h"

#endif  // COORDINATE_FOLLOWER__ACTION__FOLLOW_TARGET_H_
